<?php







$host = "localhost";





$hostname = "ITCAPSTONE";



$password = "PASSWORD";



$db = "DBNAME";







$con = mysqli_connect("$host","$hostname","$password","$db") or die ("could not connect to mysqli"); 







?>